<?
require_once($_SERVER["DOCUMENT_ROOT"]."/constants.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/../Common/database/db.php");
require_once($_SERVER["DOCUMENT_ROOT"]."/../Common/database/db_funcs.php");

/* Implementaci�n de m�ltiples sistemas dentro del sistema de tickets */
if (isset($_REQUEST["sistema"]))
  $sistema = $_REQUEST["sistema"];
else
  $sistema = 1;

if ($sistema == 1) {
  $textoHeader = 'Solicitud a Sistemas';
  $textoSubHeader = 'Este m�dulo le permitir� autorizar o rechazar una solicitud a la Gerencia de Sistemas';
}
if ($sistema == 2) {
  $textoHeader = 'Solicitud a Obras & Mantenimiento';
  $textoSubHeader = 'Este m�dulo le permitir� autorizar o rechazar una solicitud al sector de Obras & Mantenimiento';
}
if ($sistema == 3) {
  $textoHeader = 'Solicitud a Sistemas del Grupo Banco Provincia';
  $textoSubHeader = 'Este m�dulo le permitir� autorizar o rechazar una solicitud a la Gerencia de Sistemas';
}
if ($sistema == 4) {
  $textoHeader = 'Solicitud a An�lisis y Control de Gesti�n';
  $textoSubHeader = 'Este m�dulo le permitir� autorizar o rechazar una solicitud a la Gerencia de An�lisis y Control de Gesti�n';
}

$sql = "SELECT ss_notas as notas, ss_observaciones as observaciones, 1000 - length(ss_notas) as longitud
          FROM computos.css_solicitudsistemas
         WHERE ss_id = :id";
$params = array(":id" => $_REQUEST["id"]);
$stmt = DBExecSql($conn, $sql, $params);
$row = DBGetQuery($stmt);
?>

  <div id="stylized" class="formGeneric" style="font-size:12px; width:500px;">
    <form action="ticket_authorization_save.php?sistema=<?echo $sistema;?>" id="formAutorizacion" name="formAutorizacion"
          method="post" onSubmit="return ValidarFormAutorizacion(formAutorizacion)">
      <b><?echo $textoHeader;?></b>
      <br />
      <p><?echo $textoSubHeader;?></p>

      <input type="hidden" id="id" name="id" value="<?=$_REQUEST["id"]?>" />
      <input type="hidden" id="back_button" name="back_button" value="no" />
      <input type="hidden" id="back_button" name="close_button" value="yes" />

      <label>Autorizaci�n
        <span class="small">�Autoriza la realizaci�n del pedido?</span>
      </label>
      <div id="DivAutoriza">
        <select class="Combo" id="autoriza" name="autoriza">
        </select>
      </div>

      <label>Comentario
        <span class="small">Acerca de la autorizaci�n<br />(Hasta <?= $row["LONGITUD"] ?> caracteres)</span>
      </label>
      <textarea rows="3" name="comentarios" id="comentarios"></textarea>

      <button type="submit" class="btnAction">Aceptar</button>
      <div class="msg_label" id="DivAreaMensajes" style="text-align:left;"><br />Gracias por su tiempo.</div>
      <div class="spacer"></div>
    </form>
  </div>

<script type="text/javascript">
<?
// FillCombos..
$excludeHtml = True;
require_once($_SERVER["DOCUMENT_ROOT"]."/../Common/miscellaneous/refresh_combo.php");

$RCwindow = "window";

$RCfield = "autoriza";
$RCparams = array();
$RCquery = "SELECT ID, DETALLE
              FROM (SELECT 'S' ID, 'S�' DETALLE
                      FROM DUAL
                     UNION ALL
                    SELECT 'N' ID, 'No' DETALLE
                      FROM DUAL) AUTORIZA
             WHERE 1 = 1 ";
$RCselectedItem = $_REQUEST["authorize"];
FillCombo();
?>
</script>