<?
  echo "<br/><msg_label>".$_REQUEST['param1']."</msg_label>";
?>